{
  currentUser: {
    id: 1,
    username: "app-academy",
    asked_questions: {[]},
    answers: {[]},
    subscribed_topics: {[]}
  },
  forms: {
    AuthForm:{
      signUpForm: {errors: []},
      signInForm: {errors: []}
    }
    AskQuestionForm: {errors: ["body can't be blank"]},
    AnswerForm: {errors: ["body can't be blank"]},
    CommentForm: {errors: ["body can't be blank"]}    
  },
  topics: {[]}
}
